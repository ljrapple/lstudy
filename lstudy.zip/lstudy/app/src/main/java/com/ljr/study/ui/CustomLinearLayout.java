package com.ljr.study.ui;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.LinearLayout;

import com.ljr.study.utils.Logger;

public class CustomLinearLayout extends LinearLayout {
    public CustomLinearLayout(Context context) {
        super(context);
    }

    public CustomLinearLayout(Context context,
            @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public CustomLinearLayout(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public void setTag(Object tag) {
        super.setTag(tag);
        init();
    }

    private void init() {
//        Logger.setTag("logger : Custom " + getTag().toString());
        Logger.e(getTag().toString());
        setClickable(false);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        Logger.e("dispatchTouchEvent");
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        Logger.e("onInterceptTouchEvent");
        return super.onInterceptTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Logger.e("onTouchEvent  clickable =  " + isClickable());
        boolean result = super.onTouchEvent(event);
        Logger.e("onTouchEvent  result =  " + result);

        return result;
    }
}
