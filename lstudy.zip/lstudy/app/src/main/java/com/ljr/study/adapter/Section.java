package com.ljr.study.adapter;

import java.util.List;

public interface Section {

    List<BaseItem> getItemsList();
}
