package com.ljr.study.adapter;

import org.junit.Test;

public class BaseViewHolderTest {
    @Test
    public void onBound() throws Exception {
    }

}